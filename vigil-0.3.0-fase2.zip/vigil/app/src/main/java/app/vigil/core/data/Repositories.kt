package app.vigil.core.data

import android.content.ContentResolver
import android.net.Uri
import app.vigil.core.data.db.AllowedDomainDao
import app.vigil.core.data.db.AllowedDomainEntity
import app.vigil.core.data.db.BibleReadingDao
import app.vigil.core.data.db.BibleReadingEntity
import app.vigil.core.data.db.BlockedDomainDao
import app.vigil.core.data.db.BlockedDomainEntity
import app.vigil.core.data.db.FavoriteDao
import app.vigil.core.data.db.FavoriteEntity
import app.vigil.core.data.db.ProtectionEventDao
import app.vigil.core.data.db.ProtectionEventEntity
import app.vigil.core.data.db.RecoveryKind
import app.vigil.core.data.db.RecoveryLogDao
import app.vigil.core.data.db.RecoveryLogEntity
import app.vigil.core.data.db.TriggerDao
import app.vigil.core.data.db.TriggerEntity
import app.vigil.core.data.db.WatchSessionDao
import app.vigil.core.data.db.WatchSessionEntity
import app.vigil.core.util.DAY_MS
import app.vigil.core.util.DomainListParser
import app.vigil.core.util.DomainNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

enum class DomainResult { ADDED, INVALID, DUPLICATE }

/**
 * Resultado de uma importação de lista.
 * [found] = domínios válidos distintos encontrados; [added] = os que eram novos;
 * [ignoredLines] = linhas com conteúdo que não eram domínios válidos.
 */
data class ImportResult(
    val found: Int,
    val added: Int,
    val ignoredLines: Int,
    val failed: Boolean = false,
    val truncated: Boolean = false,
)

private const val IMPORT_CHUNK = 2000
private const val MAX_IMPORT_LINES = 1_000_000

class ShieldRepository(
    private val blockedDao: BlockedDomainDao,
    private val allowedDao: AllowedDomainDao,
    private val eventDao: ProtectionEventDao,
) {
    val blocked: Flow<List<BlockedDomainEntity>> = blockedDao.observeAll()
    val allowed: Flow<List<AllowedDomainEntity>> = allowedDao.observeAll()
    val events = eventDao.observeRecent(50)

    /** Só os nomes, usados pelo filtro DNS. */
    val blockedNames: Flow<List<String>> = blockedDao.observeNames()
    val allowedNames: Flow<List<String>> = allowedDao.observeNames()

    fun observeCountSince(type: String, since: Long): Flow<Int> = eventDao.observeCountSince(type, since)

    /** Registra um evento de proteção. [detail] nunca deve conter o endereço visitado — apenas a regra. */
    suspend fun logEvent(type: String, detail: String? = null) {
        eventDao.insert(ProtectionEventEntity(timestamp = System.currentTimeMillis(), type = type, detail = detail))
    }

    suspend fun pruneOldEvents() = eventDao.deleteBefore(System.currentTimeMillis() - 30 * DAY_MS)

    suspend fun addBlocked(raw: String): DomainResult {
        val domain = DomainNormalizer.normalize(raw) ?: return DomainResult.INVALID
        val id = blockedDao.insert(BlockedDomainEntity(domain = domain, createdAt = System.currentTimeMillis()))
        return if (id == -1L) DomainResult.DUPLICATE else DomainResult.ADDED
    }

    suspend fun addAllowed(raw: String): DomainResult {
        val domain = DomainNormalizer.normalize(raw) ?: return DomainResult.INVALID
        val id = allowedDao.insert(AllowedDomainEntity(domain = domain, createdAt = System.currentTimeMillis()))
        return if (id == -1L) DomainResult.DUPLICATE else DomainResult.ADDED
    }

    suspend fun removeBlocked(id: Long) = blockedDao.delete(id)
    suspend fun removeAllowed(id: Long) = allowedDao.delete(id)

    /** Insere domínios já normalizados em lotes. Retorna quantos eram novos. */
    suspend fun addBlockedDomains(domains: Collection<String>): Int {
        val now = System.currentTimeMillis()
        var added = 0
        for (chunk in domains.chunked(IMPORT_CHUNK)) {
            val ids = blockedDao.insertAll(chunk.map { BlockedDomainEntity(domain = it, createdAt = now) })
            added += ids.count { it != -1L }
        }
        return added
    }

    suspend fun addAllowedDomains(domains: Collection<String>): Int {
        val now = System.currentTimeMillis()
        var added = 0
        for (chunk in domains.chunked(IMPORT_CHUNK)) {
            val ids = allowedDao.insertAll(chunk.map { AllowedDomainEntity(domain = it, createdAt = now) })
            added += ids.count { it != -1L }
        }
        return added
    }

    suspend fun addBasicBlocklist(): Int = addBlockedDomains(ShieldDefaults.BASIC_BLOCKLIST)

    /** Importa um arquivo de texto (formato hosts ou um domínio por linha) escolhido pelo usuário. */
    suspend fun importFrom(resolver: ContentResolver, uri: Uri, toBlocklist: Boolean): ImportResult =
        withContext(Dispatchers.IO) {
            val domains = LinkedHashSet<String>()
            var lines = 0
            var ignored = 0
            var truncated = false
            val stream = try {
                resolver.openInputStream(uri)
            } catch (e: Exception) {
                null
            } ?: return@withContext ImportResult(0, 0, 0, failed = true)

            try {
                stream.bufferedReader().useLines { sequence ->
                    for (line in sequence) {
                        lines++
                        if (lines > MAX_IMPORT_LINES) {
                            truncated = true
                            break
                        }
                        val domain = DomainListParser.parseLine(line)
                        if (domain != null) {
                            domains.add(domain)
                        } else if (!DomainListParser.isBlankOrComment(line)) {
                            ignored++
                        }
                    }
                }
            } catch (e: Exception) {
                return@withContext ImportResult(0, 0, 0, failed = true)
            }

            val added = if (toBlocklist) addBlockedDomains(domains) else addAllowedDomains(domains)
            ImportResult(found = domains.size, added = added, ignoredLines = ignored, truncated = truncated)
        }
}

class RecoveryRepository(
    private val logDao: RecoveryLogDao,
    private val triggerDao: TriggerDao,
) {
    val logs: Flow<List<RecoveryLogEntity>> = logDao.observeAll()
    val triggers: Flow<List<TriggerEntity>> = triggerDao.observeAll()

    suspend fun add(kind: RecoveryKind, triggerName: String?, intensity: Int, note: String?) {
        logDao.insert(
            RecoveryLogEntity(
                timestamp = System.currentTimeMillis(),
                kind = kind.name,
                triggerName = triggerName?.takeIf { it.isNotBlank() },
                intensity = intensity.coerceIn(1, 5),
                note = note?.trim()?.takeIf { it.isNotEmpty() },
            ),
        )
    }

    suspend fun deleteLog(id: Long) = logDao.delete(id)

    suspend fun addTrigger(name: String): Boolean {
        val clean = name.trim()
        if (clean.isEmpty()) return false
        return triggerDao.insert(TriggerEntity(name = clean, createdAt = System.currentTimeMillis())) != -1L
    }
}

class WatchRepository(private val dao: WatchSessionDao) {
    val sessions: Flow<List<WatchSessionEntity>> = dao.observeAll()

    suspend fun record(startedAt: Long, durationSec: Int, completed: Boolean, activity: String?) {
        dao.insert(
            WatchSessionEntity(
                startedAt = startedAt,
                durationSec = durationSec,
                completed = completed,
                activity = activity,
            ),
        )
    }
}

class DevotionRepository(
    private val readingDao: BibleReadingDao,
    private val favoriteDao: FavoriteDao,
) {
    val readings: Flow<List<BibleReadingEntity>> = readingDao.observeAll()
    val favoriteKeys: Flow<Set<String>> = favoriteDao.observeAll().map { list -> list.map { it.readingKey }.toSet() }

    suspend fun markRead(key: String) {
        readingDao.insert(BibleReadingEntity(readingKey = key, readAt = System.currentTimeMillis()))
    }

    suspend fun setFavorite(key: String, favorite: Boolean) {
        if (favorite) {
            favoriteDao.insert(FavoriteEntity(readingKey = key, createdAt = System.currentTimeMillis()))
        } else {
            favoriteDao.delete(key)
        }
    }
}
