package app.vigil.feature.shield.engine

/**
 * Decide se um nome DNS deve ser bloqueado.
 *
 * Regras:
 * - Uma entrada "exemplo.com" cobre o próprio domínio e todos os subdomínios ("a.b.exemplo.com").
 * - Não há correspondência parcial de rótulo: "naoexemplo.com" NÃO casa com "exemplo.com".
 * - A lista de permissões tem precedência: se o nome (ou algum domínio-pai dele) estiver na lista de
 *   permissões, nunca é bloqueado. Permitir "www.exemplo.com" libera só esse nome; bloquear
 *   "exemplo.com" continua valendo para os demais.
 *
 * As entradas devem vir normalizadas (minúsculas, ASCII/punycode) por [app.vigil.core.util.DomainNormalizer].
 */
class DomainMatcher(blocked: Collection<String>, allowed: Collection<String>) {
    private val blockedSet: Set<String> = HashSet(blocked)
    private val allowedSet: Set<String> = HashSet(allowed)

    /** Retorna a regra da lista de bloqueio que casou, ou null se o nome não deve ser bloqueado. */
    fun matchBlocked(rawName: String): String? {
        if (blockedSet.isEmpty()) return null
        val name = rawName.trim().trimEnd('.').lowercase()
        if (name.isEmpty()) return null
        if (suffixes(name).any { it in allowedSet }) return null
        return suffixes(name).firstOrNull { it in blockedSet }
    }

    private fun suffixes(name: String): Sequence<String> = sequence {
        var current = name
        while (true) {
            yield(current)
            val dot = current.indexOf('.')
            if (dot < 0) break
            current = current.substring(dot + 1)
        }
    }
}
