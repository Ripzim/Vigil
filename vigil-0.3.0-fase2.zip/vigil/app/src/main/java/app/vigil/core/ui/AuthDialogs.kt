package app.vigil.core.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import app.vigil.core.security.AuthResult
import app.vigil.core.security.PasswordManager
import app.vigil.core.ui.theme.VigilColors
import kotlinx.coroutines.launch

/** Ação protegida por senha: [onGranted] só roda depois de a senha ser confirmada. */
class AuthRequest(val title: String, val onGranted: () -> Unit)

/** Pede a senha atual. Mostre-o quando houver uma [AuthRequest] pendente. */
@Composable
fun AuthDialogHost(
    request: AuthRequest?,
    onClose: () -> Unit,
    verify: suspend (String) -> AuthResult,
) {
    if (request == null) return
    var password by remember(request) { mutableStateOf("") }
    var error by remember(request) { mutableStateOf<String?>(null) }
    var busy by remember(request) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(request.title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        error = null
                    },
                    singleLine = true,
                    label = { Text("Senha") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = error != null,
                )
                error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = VigilColors.Error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && password.isNotEmpty(),
                onClick = {
                    busy = true
                    scope.launch {
                        when (val result = verify(password)) {
                            AuthResult.Ok -> {
                                request.onGranted()
                                onClose()
                            }
                            AuthResult.Wrong -> error = "Senha incorreta."
                            is AuthResult.Locked -> error = "Muitas tentativas. Aguarde ${result.seconds}s."
                        }
                        busy = false
                    }
                },
            ) { Text("Confirmar") }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onClose() }) { Text("Cancelar") } },
    )
}

/**
 * Formulário para definir uma nova senha. [onSubmit] recebe (senhaAtual, novaSenha) e devolve uma
 * mensagem de erro, ou null em caso de sucesso (o diálogo então fecha).
 */
@Composable
fun PasswordSetDialog(
    title: String,
    requireCurrent: Boolean,
    onDismiss: () -> Unit,
    onSubmit: suspend (current: String, new: String) -> String?,
) {
    var current by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (requireCurrent) {
                    PasswordField("Senha atual", current) { current = it; error = null }
                }
                PasswordField("Nova senha (mín. ${PasswordManager.MIN_LENGTH} caracteres)", new) { new = it; error = null }
                PasswordField("Repita a nova senha", confirm) { confirm = it; error = null }
                error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = VigilColors.Error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    when {
                        new.length < PasswordManager.MIN_LENGTH ->
                            error = "Use pelo menos ${PasswordManager.MIN_LENGTH} caracteres."
                        new != confirm -> error = "As senhas não coincidem."
                        else -> {
                            busy = true
                            scope.launch {
                                val message = onSubmit(current, new)
                                busy = false
                                if (message == null) onDismiss() else error = message
                            }
                        }
                    }
                },
            ) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onDismiss() }) { Text("Cancelar") } },
    )
}

@Composable
private fun PasswordField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
    )
}
