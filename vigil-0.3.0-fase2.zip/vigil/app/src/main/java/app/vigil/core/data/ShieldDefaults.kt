package app.vigil.core.data

/**
 * Lista inicial MÍNIMA, apenas para o usuário conseguir testar o filtro de imediato.
 * Não é uma proteção completa: o caminho recomendado é importar uma lista pública mantida pela comunidade
 * (formato hosts ou um domínio por linha) pela tela do Shield.
 */
object ShieldDefaults {
    val BASIC_BLOCKLIST: List<String> = listOf(
        "pornhub.com",
        "xvideos.com",
        "xnxx.com",
        "xhamster.com",
        "redtube.com",
        "youporn.com",
        "spankbang.com",
        "eporner.com",
    )
}
