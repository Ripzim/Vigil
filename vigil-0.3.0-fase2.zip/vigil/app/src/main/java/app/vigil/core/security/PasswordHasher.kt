package app.vigil.core.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Hash de senha com PBKDF2-HMAC-SHA256 e sal aleatório.
 *
 * Formato do registro: `v<versão>:<iterações>:<sal base64>:<hash base64>`
 * - v1: apenas PBKDF2.
 * - v2: PBKDF2 e, em seguida, a função [pepper] (HMAC com chave do Android Keystore, que não sai do aparelho).
 *   Se o Keystore falhar ao criar a senha, cai para v1 em vez de impedir o usuário de definir a senha.
 *
 * A senha em texto puro nunca é armazenada. Esta classe é Kotlin/JVM puro para poder ser testada fora do Android.
 */
class PasswordHasher(
    private val pepper: ((ByteArray) -> ByteArray)? = null,
    private val iterations: Int = DEFAULT_ITERATIONS,
) {
    fun hash(password: CharArray): String {
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val derived = pbkdf2(password, salt, iterations)
        val peppered = pepper?.let { fn -> runCatching { fn(derived) }.getOrNull() }
        val version = if (peppered != null) 2 else 1
        val finalHash = peppered ?: derived
        return listOf(
            "v$version",
            iterations.toString(),
            Base64.getEncoder().encodeToString(salt),
            Base64.getEncoder().encodeToString(finalHash),
        ).joinToString(":")
    }

    fun verify(password: CharArray, record: String): Boolean {
        val parts = record.split(":")
        if (parts.size != 4) return false
        val version = when (parts[0]) {
            "v1" -> 1
            "v2" -> 2
            else -> return false
        }
        val iter = parts[1].toIntOrNull() ?: return false
        if (iter < 1) return false
        val salt = try {
            Base64.getDecoder().decode(parts[2])
        } catch (e: IllegalArgumentException) {
            return false
        }
        val expected = try {
            Base64.getDecoder().decode(parts[3])
        } catch (e: IllegalArgumentException) {
            return false
        }
        val derived = pbkdf2(password, salt, iter)
        val candidate = if (version == 2) {
            val fn = pepper ?: return false
            runCatching { fn(derived) }.getOrNull() ?: return false
        } else {
            derived
        }
        return MessageDigest.isEqual(candidate, expected)
    }

    private fun pbkdf2(password: CharArray, salt: ByteArray, iter: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iter, KEY_BITS)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    companion object {
        const val DEFAULT_ITERATIONS = 150_000
        private const val SALT_BYTES = 16
        private const val KEY_BITS = 256
    }
}
