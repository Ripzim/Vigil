package app.vigil.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import app.vigil.core.di.AppContainer
import app.vigil.core.di.vigilViewModel
import app.vigil.core.security.AuthResult
import app.vigil.core.security.PasswordManager
import app.vigil.core.ui.AuthDialogHost
import app.vigil.core.ui.AuthRequest
import app.vigil.core.ui.Hairline
import app.vigil.core.ui.KeyValueRow
import app.vigil.core.ui.PasswordSetDialog
import app.vigil.core.ui.SectionLabel
import app.vigil.core.ui.VigilScreen
import app.vigil.core.ui.theme.VigilColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    private val passwords = c.passwordManager

    val advanced = c.settings.advancedDashboard.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val hasPassword = passwords.hasPassword.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val emergencyAt = passwords.emergencyRequestedAt.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun setAdvanced(value: Boolean) {
        viewModelScope.launch { c.settings.setAdvancedDashboard(value) }
    }

    suspend fun hasPasswordNow() = passwords.hasPasswordNow()
    suspend fun verifyPassword(password: String): AuthResult = passwords.verify(password)

    /** Define ou troca a senha. Devolve uma mensagem de erro, ou null em caso de sucesso. */
    suspend fun savePassword(current: String, new: String, requireCurrent: Boolean): String? {
        if (requireCurrent) {
            when (val r = passwords.verify(current)) {
                AuthResult.Ok -> Unit
                AuthResult.Wrong -> return "Senha atual incorreta."
                is AuthResult.Locked -> return "Muitas tentativas. Aguarde ${r.seconds}s."
            }
        }
        return if (passwords.setPassword(new)) null else "Não foi possível salvar a senha."
    }

    suspend fun emergencyReset(new: String): String? =
        if (passwords.resetViaEmergency(new)) null else "A espera de 24 horas ainda não terminou."

    fun requestEmergency() {
        viewModelScope.launch { passwords.requestEmergencyReset() }
    }

    fun cancelEmergency() {
        viewModelScope.launch { passwords.cancelEmergencyReset() }
    }

    fun removePassword() {
        viewModelScope.launch { passwords.removePassword() }
    }

    fun wipe(onDone: () -> Unit) {
        viewModelScope.launch {
            c.wipeAllData()
            onDone()
        }
    }
}

private enum class PasswordDialog { NONE, SET, CHANGE, EMERGENCY }

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val vm = vigilViewModel { SettingsViewModel(it) }
    val scope = rememberCoroutineScope()
    val advanced by vm.advanced.collectAsStateWithLifecycle()
    val hasPassword by vm.hasPassword.collectAsStateWithLifecycle()
    val emergencyAt by vm.emergencyAt.collectAsStateWithLifecycle()
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(30_000)
            value = System.currentTimeMillis()
        }
    }

    var confirmWipe by remember { mutableStateOf(false) }
    var wiped by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf(PasswordDialog.NONE) }
    var authRequest by remember { mutableStateOf<AuthRequest?>(null) }

    fun guarded(title: String, action: () -> Unit) {
        scope.launch {
            if (vm.hasPasswordNow()) authRequest = AuthRequest(title, action) else action()
        }
    }

    val context = LocalContext.current
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    VigilScreen("Configurações", onBack) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SectionLabel("Painel")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Painel avançado", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = advanced, onCheckedChange = vm::setAdvanced)
            }
            Hairline()

            SectionLabel("Proteção por senha")
            Text(
                if (hasPassword) {
                    "Senha definida. Ela é pedida para desativar o Shield, remover domínios bloqueados, " +
                        "mexer na lista de permissões, remover a senha e apagar os dados."
                } else {
                    "Nenhuma senha definida. Defina uma para dificultar alterações impulsivas na proteção."
                },
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "A senha é um freio contra impulsos, não um cadeado: o Android sempre permite desligar a VPN " +
                    "nas configurações do sistema e desinstalar o app.",
                style = MaterialTheme.typography.bodySmall,
                color = VigilColors.Muted,
            )
            if (!hasPassword) {
                Button(onClick = { dialog = PasswordDialog.SET }) { Text("Definir senha") }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { dialog = PasswordDialog.CHANGE }) { Text("Alterar senha") }
                    OutlinedButton(onClick = { guarded("Remover senha") { vm.removePassword() } }) { Text("Remover senha") }
                }
                val requestedAt = emergencyAt
                if (requestedAt == null) {
                    TextButton(onClick = { vm.requestEmergency() }) { Text("Esqueci a senha") }
                    Text(
                        "Inicia uma espera de 24 horas. Depois dela você poderá definir uma nova senha sem " +
                            "informar a antiga. Lembrar a senha e usá-la cancela o pedido.",
                        style = MaterialTheme.typography.labelSmall,
                        color = VigilColors.Muted,
                    )
                } else {
                    val remaining = requestedAt + PasswordManager.EMERGENCY_WAIT_MS - now
                    if (remaining > 0) {
                        val hours = remaining / 3_600_000
                        val minutes = (remaining % 3_600_000) / 60_000
                        Text(
                            "Redefinição de emergência liberada em ${hours}h ${minutes}min.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VigilColors.Warning,
                        )
                        TextButton(onClick = { vm.cancelEmergency() }) { Text("Cancelar pedido") }
                    } else {
                        Text(
                            "A espera terminou. Você já pode definir uma nova senha.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = VigilColors.Green,
                        )
                        Button(onClick = { dialog = PasswordDialog.EMERGENCY }) { Text("Redefinir senha agora") }
                        TextButton(onClick = { vm.cancelEmergency() }) { Text("Cancelar pedido") }
                    }
                }
            }
            Hairline()

            SectionLabel("Privacidade")
            Text(
                "Todos os dados ficam somente neste aparelho. O app não tem contas, telemetria, anúncios nem " +
                    "sincronização, e o backup do Android está desativado para os dados do VIGIL. A permissão de " +
                    "internet existe apenas para o filtro DNS encaminhar ao DNS da sua rede as consultas que não " +
                    "foram bloqueadas.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Limite técnico: o banco de dados ainda não é criptografado em repouso. A senha é guardada " +
                    "apenas como hash (PBKDF2 com chave do Android Keystore).",
                style = MaterialTheme.typography.bodySmall,
                color = VigilColors.Warning,
            )
            Hairline()

            SectionLabel("Dados")
            Text(
                "Apaga todos os registros, listas, a senha e as configurações do VIGIL neste aparelho. " +
                    "Desliga o Shield. Não pode ser desfeito.",
                style = MaterialTheme.typography.bodySmall,
                color = VigilColors.Muted,
            )
            Button(
                onClick = { guarded("Apagar todos os dados") { confirmWipe = true } },
                colors = ButtonDefaults.buttonColors(containerColor = VigilColors.Error, contentColor = VigilColors.Black),
            ) { Text("Apagar todos os meus dados") }
            if (wiped) {
                Text("Dados apagados.", style = MaterialTheme.typography.bodyMedium, color = VigilColors.Green)
            }
            Hairline()

            SectionLabel("Sobre")
            KeyValueRow("Versão", version, VigilColors.Muted)
            KeyValueRow("Plataforma", "Android nativo", VigilColors.Muted)
            Column(Modifier.padding(bottom = 24.dp)) {}
        }
    }

    when (dialog) {
        PasswordDialog.NONE -> Unit
        PasswordDialog.SET -> PasswordSetDialog(
            title = "Definir senha",
            requireCurrent = false,
            onDismiss = { dialog = PasswordDialog.NONE },
            onSubmit = { _, new -> vm.savePassword("", new, requireCurrent = false) },
        )
        PasswordDialog.CHANGE -> PasswordSetDialog(
            title = "Alterar senha",
            requireCurrent = true,
            onDismiss = { dialog = PasswordDialog.NONE },
            onSubmit = { current, new -> vm.savePassword(current, new, requireCurrent = true) },
        )
        PasswordDialog.EMERGENCY -> PasswordSetDialog(
            title = "Redefinir senha",
            requireCurrent = false,
            onDismiss = { dialog = PasswordDialog.NONE },
            onSubmit = { _, new -> vm.emergencyReset(new) },
        )
    }

    AuthDialogHost(
        request = authRequest,
        onClose = { authRequest = null },
        verify = { vm.verifyPassword(it) },
    )

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Apagar todos os dados?") },
            text = {
                Text(
                    "Registros, listas de domínios, histórico de leitura, favoritos, senha e configurações " +
                        "serão removidos permanentemente, e o Shield será desligado.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmWipe = false
                    vm.wipe { wiped = true }
                }) { Text("Apagar", color = VigilColors.Error) }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancelar") } },
        )
    }
}
