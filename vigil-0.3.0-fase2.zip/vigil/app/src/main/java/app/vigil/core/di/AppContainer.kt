package app.vigil.core.di

import android.content.Context
import androidx.room.Room
import app.vigil.core.data.DevotionRepository
import app.vigil.core.data.RecoveryRepository
import app.vigil.core.data.SettingsRepository
import app.vigil.core.data.ShieldRepository
import app.vigil.core.data.WatchRepository
import app.vigil.core.data.db.Migrations
import app.vigil.core.data.db.VigilDatabase
import app.vigil.core.data.vigilDataStore
import app.vigil.core.security.PasswordManager
import app.vigil.feature.shield.engine.ShieldController
import app.vigil.feature.shield.engine.ShieldRuntime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** Injeção de dependências manual. Um único contêiner por processo, criado em [app.vigil.VigilApp]. */
class AppContainer(context: Context) {
    private val appContext: Context = context.applicationContext

    /** Escopo do processo, para trabalho que não pode morrer junto com uma tela ou com o serviço de VPN. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val database: VigilDatabase = Room.databaseBuilder(
        appContext,
        VigilDatabase::class.java,
        "vigil.db",
    ).addMigrations(*Migrations.ALL).build()

    val settings = SettingsRepository(appContext.vigilDataStore)
    val shield = ShieldRepository(database.blockedDomainDao(), database.allowedDomainDao(), database.protectionEventDao())
    val recovery = RecoveryRepository(database.recoveryLogDao(), database.triggerDao())
    val watch = WatchRepository(database.watchSessionDao())
    val devotion = DevotionRepository(database.bibleReadingDao(), database.favoriteDao())
    val passwordManager = PasswordManager(settings)

    /** Apaga todos os dados do usuário: banco Room e configurações (inclusive a senha). Para o Shield antes. */
    suspend fun wipeAllData() {
        if (ShieldRuntime.running.value) {
            ShieldController.stop(appContext)
            withTimeoutOrNull(3_000) { ShieldRuntime.running.first { !it } }
            delay(500) // deixa terminar o registro assíncrono do evento de parada
        }
        withContext(Dispatchers.IO) {
            database.clearAllTables()
            settings.clear()
        }
    }
}
