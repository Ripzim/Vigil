package app.vigil.feature.shield

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import app.vigil.core.data.DomainResult
import app.vigil.core.di.AppContainer
import app.vigil.core.di.vigilViewModel
import app.vigil.core.security.AuthResult
import app.vigil.core.ui.AuthDialogHost
import app.vigil.core.ui.AuthRequest
import app.vigil.core.ui.EmptyState
import app.vigil.core.ui.Hairline
import app.vigil.core.ui.SectionLabel
import app.vigil.core.ui.StatusBanner
import app.vigil.core.ui.VigilScreen
import app.vigil.core.ui.theme.VigilColors
import app.vigil.core.util.formatDateTime
import app.vigil.feature.shield.engine.ShieldController
import app.vigil.feature.shield.engine.ShieldRuntime
import java.net.InetAddress
import java.net.UnknownHostException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Notice(val text: String, val isError: Boolean)

class ShieldViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.shield

    val blocked = repo.blocked.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allowed = repo.allowed.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val events = repo.events.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val shieldEnabled = c.settings.shieldEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val running: StateFlow<Boolean> = ShieldRuntime.running
    val startError: StateFlow<String?> = ShieldRuntime.error

    private val _notice = MutableStateFlow<Notice?>(null)
    val notice: StateFlow<Notice?> = _notice

    private val _testResult = MutableStateFlow<String?>(null)
    val testResult: StateFlow<String?> = _testResult

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    suspend fun hasPasswordNow() = c.passwordManager.hasPasswordNow()
    suspend fun verifyPassword(password: String): AuthResult = c.passwordManager.verify(password)

    fun add(raw: String, toBlocklist: Boolean, onAdded: () -> Unit) {
        viewModelScope.launch {
            val result = if (toBlocklist) repo.addBlocked(raw) else repo.addAllowed(raw)
            _notice.value = when (result) {
                DomainResult.ADDED -> null
                DomainResult.DUPLICATE -> Notice("Este domínio já está na lista.", true)
                DomainResult.INVALID -> Notice("Domínio inválido. Exemplo: exemplo.com", true)
            }
            if (result == DomainResult.ADDED) onAdded()
        }
    }

    fun remove(id: Long, fromBlocklist: Boolean) {
        viewModelScope.launch { if (fromBlocklist) repo.removeBlocked(id) else repo.removeAllowed(id) }
    }

    fun addBasicList() {
        viewModelScope.launch {
            val added = repo.addBasicBlocklist()
            _notice.value = Notice("$added domínio(s) novo(s) adicionado(s) à lista de bloqueio.", false)
        }
    }

    fun importList(resolver: android.content.ContentResolver, uri: android.net.Uri, toBlocklist: Boolean) {
        viewModelScope.launch {
            _busy.value = true
            _notice.value = Notice("Importando…", false)
            val r = repo.importFrom(resolver, uri, toBlocklist)
            _busy.value = false
            _notice.value = if (r.failed) {
                Notice("Não foi possível ler o arquivo.", true)
            } else {
                val extra = buildString {
                    if (r.ignoredLines > 0) append(" ${r.ignoredLines} linha(s) ignorada(s).")
                    if (r.truncated) append(" Arquivo limitado às primeiras 1.000.000 linhas.")
                }
                Notice("Importação concluída: ${r.added} novo(s) de ${r.found} domínio(s) válido(s).$extra", false)
            }
        }
    }

    fun clearNotice() {
        _notice.value = null
    }

    /**
     * Teste real no aparelho: resolve o primeiro domínio bloqueado e um domínio de controle.
     * O resultado só é "OK" se o domínio bloqueado falhar E o de controle resolver, o que distingue
     * bloqueio de simples falta de internet.
     */
    fun selfTest() {
        viewModelScope.launch {
            val domain = blocked.value.firstOrNull()?.domain
            if (!ShieldRuntime.running.value) {
                _testResult.value = "Ative a proteção antes de testar."
                return@launch
            }
            if (domain == null) {
                _testResult.value = "Adicione ao menos um domínio bloqueado para testar."
                return@launch
            }
            _testResult.value = "Testando…"
            _testResult.value = withContext(Dispatchers.IO) {
                val blockedResolved = resolves(domain)
                val controlResolved = resolves(CONTROL_DOMAIN)
                when {
                    blockedResolved ->
                        "FALHA: $domain resolveu, então NÃO foi bloqueado. Verifique se o DNS privado do Android " +
                            "e o DNS seguro do navegador estão desativados."
                    controlResolved ->
                        "OK: $domain foi bloqueado e $CONTROL_DOMAIN resolveu normalmente."
                    else ->
                        "Inconclusivo: nem $CONTROL_DOMAIN resolveu. Verifique a conexão e tente de novo."
                }
            }
        }
    }

    private fun resolves(host: String): Boolean = try {
        InetAddress.getAllByName(host)
        true
    } catch (e: UnknownHostException) {
        false
    }

    private companion object {
        const val CONTROL_DOMAIN = "example.com"
    }
}

private fun eventLabel(type: String, detail: String?): String = when (type) {
    "BLOCK" -> "bloqueio · regra $detail"
    "SHIELD_ON" -> "proteção ativada"
    "SHIELD_OFF" -> "proteção desativada"
    "SHIELD_INTERRUPTED" -> "proteção interrompida"
    else -> type
}

@Composable
fun ShieldScreen(onBack: () -> Unit) {
    val vm = vigilViewModel { ShieldViewModel(it) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val blocked by vm.blocked.collectAsStateWithLifecycle()
    val allowed by vm.allowed.collectAsStateWithLifecycle()
    val events by vm.events.collectAsStateWithLifecycle()
    val running by vm.running.collectAsStateWithLifecycle()
    val enabled by vm.shieldEnabled.collectAsStateWithLifecycle()
    val startError by vm.startError.collectAsStateWithLifecycle()
    val notice by vm.notice.collectAsStateWithLifecycle()
    val testResult by vm.testResult.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()

    var tab by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var authRequest by remember { mutableStateOf<AuthRequest?>(null) }
    var importToBlocklist by remember { mutableStateOf(true) }
    val onBlocklist = tab == 0

    /** Executa [action] direto se não há senha; senão pede a senha antes. */
    fun guarded(title: String, action: () -> Unit) {
        scope.launch {
            if (vm.hasPasswordNow()) authRequest = AuthRequest(title, action) else action()
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) ShieldController.start(context)
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importList(context.contentResolver, uri, importToBlocklist)
    }

    fun setShield(enable: Boolean) {
        if (enable) {
            val consent = ShieldController.prepareIntent(context)
            if (consent != null) vpnPermissionLauncher.launch(consent) else ShieldController.start(context)
        } else {
            guarded("Desativar proteção") { ShieldController.stop(context) }
        }
    }

    val statusText = when {
        running -> "PROTEÇÃO ATIVA — filtro DNS local em execução."
        enabled -> "PROTEÇÃO INTERROMPIDA — o filtro estava ligado e parou (reinício do aparelho, outra VPN " +
            "ou permissão revogada). Ative novamente."
        else -> "PROTEÇÃO INATIVA — nada está sendo bloqueado."
    }

    VigilScreen("Shield", onBack) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item { StatusBanner(statusText, if (running) VigilColors.Green else VigilColors.Warning) }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Filtro DNS", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = running, onCheckedChange = { setShield(it) })
                }
            }
            startError?.let { msg ->
                item { Text(msg, style = MaterialTheme.typography.bodySmall, color = VigilColors.Error) }
            }
            item {
                Text(
                    "O filtro bloqueia consultas DNS dos apps (somente IPv4/UDP). Não inspeciona HTTPS nem conteúdo. " +
                        "Não protege contra apps com DNS próprio, nem se o \"DNS privado\" do Android ou o \"DNS seguro\" " +
                        "do navegador estiverem em modo estrito. Desative-os em Configurações e no Chrome. " +
                        "O Android sempre permite desligar a VPN em Configurações > Conexões.",
                    style = MaterialTheme.typography.bodySmall,
                    color = VigilColors.Muted,
                )
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(onClick = { vm.selfTest() }) { Text("Testar bloqueio") }
                }
            }
            testResult?.let { result ->
                item {
                    val color = if (result.startsWith("OK")) VigilColors.Green else VigilColors.Warning
                    Text(result, style = MaterialTheme.typography.bodySmall, color = color)
                }
                item {
                    Text(
                        "O teste pressupõe que o domínio bloqueado existe de verdade na internet.",
                        style = MaterialTheme.typography.labelSmall,
                        color = VigilColors.Muted,
                    )
                }
            }

            item { Hairline() }
            item {
                TabRow(
                    selectedTabIndex = tab,
                    containerColor = Color.Black,
                    contentColor = VigilColors.Green,
                ) {
                    Tab(
                        selected = onBlocklist,
                        onClick = { tab = 0; input = ""; vm.clearNotice() },
                        text = { Text("Bloqueados (${blocked.size})") },
                    )
                    Tab(
                        selected = !onBlocklist,
                        onClick = { tab = 1; input = ""; vm.clearNotice() },
                        text = { Text("Permitidos (${allowed.size})") },
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it; vm.clearNotice() },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("domínio, ex.: exemplo.com") },
                        isError = notice?.isError == true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    )
                    Button(onClick = {
                        if (onBlocklist) {
                            vm.add(input, true) { input = "" }
                        } else {
                            guarded("Adicionar à lista de permissões") { vm.add(input, false) { input = "" } }
                        }
                    }) { Text("Adicionar") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !busy,
                        onClick = {
                            importToBlocklist = onBlocklist
                            if (onBlocklist) {
                                importLauncher.launch(arrayOf("*/*"))
                            } else {
                                guarded("Importar lista de permissões") { importLauncher.launch(arrayOf("*/*")) }
                            }
                        },
                    ) { Text("Importar arquivo") }
                    if (onBlocklist) {
                        OutlinedButton(onClick = { vm.addBasicList() }) { Text("Lista inicial mínima") }
                    }
                }
            }
            if (onBlocklist) {
                item {
                    Text(
                        "Importe uma lista pública (formato hosts ou um domínio por linha). A lista inicial " +
                            "mínima tem só 8 domínios, serve para testar e não é proteção completa.",
                        style = MaterialTheme.typography.labelSmall,
                        color = VigilColors.Muted,
                    )
                }
            }
            notice?.let { n ->
                item {
                    Text(
                        n.text,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (n.isError) VigilColors.Error else VigilColors.Green,
                    )
                }
            }

            if (onBlocklist) {
                if (blocked.isEmpty()) item { EmptyState("Nenhum domínio bloqueado.") }
                items(blocked, key = { "b${it.id}" }) { d ->
                    DomainRow(d.domain) { guarded("Remover domínio bloqueado") { vm.remove(d.id, true) } }
                }
            } else {
                if (allowed.isEmpty()) item { EmptyState("Nenhum domínio permitido.") }
                items(allowed, key = { "a${it.id}" }) { d ->
                    DomainRow(d.domain) { vm.remove(d.id, false) }
                }
            }

            item { Hairline() }
            item { SectionLabel("Eventos de proteção") }
            if (events.isEmpty()) {
                item { EmptyState("Nenhum evento. O histórico guarda só a regra que bloqueou, nunca o endereço visitado.") }
            }
            items(events, key = { "e${it.id}" }) { e ->
                Text(
                    "${e.timestamp.formatDateTime()}  ${eventLabel(e.type, e.detail)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = VigilColors.Muted,
                )
            }
        }
    }

    AuthDialogHost(
        request = authRequest,
        onClose = { authRequest = null },
        verify = { vm.verifyPassword(it) },
    )
}

@Composable
private fun DomainRow(domain: String, onDelete: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(domain, style = MaterialTheme.typography.bodyMedium)
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Remover $domain", tint = VigilColors.Muted)
        }
    }
}
