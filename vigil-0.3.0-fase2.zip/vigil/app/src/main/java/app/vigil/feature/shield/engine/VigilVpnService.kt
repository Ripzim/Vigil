package app.vigil.feature.shield.engine

import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import app.vigil.VigilApp
import app.vigil.core.di.AppContainer
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Filtro DNS local do VIGIL Shield.
 *
 * Como funciona:
 * - Cria uma VPN que roteia APENAS um endereço virtual de DNS (10.111.222.2/32) para a interface TUN.
 *   Todo o restante do tráfego do aparelho segue direto pela rede normal, sem passar pelo app.
 * - Lê as consultas DNS (UDP/53) que chegam nessa interface. Se o nome casa com a lista de bloqueio
 *   (e não está na de permissões), responde NXDOMAIN localmente. Caso contrário, encaminha a consulta
 *   ao DNS da rede atual por um socket protegido (fora da VPN) e devolve a resposta.
 * - Não inspeciona HTTPS, não instala certificados e não lê conteúdo. O histórico guarda só a REGRA
 *   que bloqueou (nunca o endereço digitado/visitado).
 *
 * Limitações conhecidas (documentadas também na interface):
 * - Só trata DNS sobre UDP e IPv4. DNS sobre TCP e IPv6 não são tratados.
 * - Não alcança apps que usam DNS próprio (DoH/DoT embutido), "DNS privado" estrito do Android
 *   ou "DNS seguro" do Chrome, nem acesso direto por endereço IP.
 */
@OptIn(FlowPreview::class)
class VigilVpnService : VpnService() {

    companion object {
        const val ACTION_START = "app.vigil.action.SHIELD_START"
        const val ACTION_STOP = "app.vigil.action.SHIELD_STOP"

        private const val VPN_ADDRESS = "10.111.222.1"
        private const val DNS_ADDRESS = "10.111.222.2"
        private val DNS_BYTES = byteArrayOf(10, 111, 222.toByte(), 2)
        private const val WORKERS = 6
        private const val UPSTREAM_TIMEOUT_MS = 4000
        private const val UPSTREAM_REFRESH_MS = 15_000L
        private const val LOG_THROTTLE_MS = 30_000L
    }

    /** Servidor DNS de saída e a rede (não-VPN) pela qual ele deve ser alcançado. */
    private class ResolverTarget(val network: Network?, val address: InetAddress)

    private val container: AppContainer get() = (application as VigilApp).container

    @Volatile private var started = false
    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var matcher = DomainMatcher(emptyList(), emptyList())
    @Volatile private var upstream: ResolverTarget? = null
    @Volatile private var upstreamAt = 0L
    private var scope: CoroutineScope? = null
    private var pool: ExecutorService? = null
    private val lastLogged = ConcurrentHashMap<String, Long>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopShield(userRequested = true)
            stopSelf()
            return START_NOT_STICKY
        }
        startShield()
        return START_STICKY
    }

    override fun onRevoke() {
        stopShield(userRequested = false)
        super.onRevoke()
    }

    override fun onDestroy() {
        stopShield(userRequested = false)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- ciclo de vida

    private fun startShield() {
        if (started) return
        started = true
        ShieldRuntime.setError(null)
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = s
        s.launch {
            val shield = container.shield
            try {
                // Carrega as listas ANTES de abrir a VPN para não haver janela sem bloqueio.
                matcher = DomainMatcher(shield.blockedNames.first(), shield.allowedNames.first())
                upstream = findUpstream()
                upstreamAt = SystemClock.elapsedRealtime()

                val fd = buildInterface()
                if (fd == null) {
                    failStart("Não foi possível criar a interface VPN. A permissão pode ter sido revogada.")
                    return@launch
                }
                if (!started) { // parado enquanto iniciava
                    fd.close()
                    return@launch
                }
                tun = fd
                pool = Executors.newFixedThreadPool(WORKERS)
                ShieldRuntime.setRunning(true)
                container.appScope.launch {
                    container.settings.setShieldEnabled(true)
                    shield.logEvent("SHIELD_ON")
                    shield.pruneOldEvents()
                }
                startReader(fd)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failStart("Falha ao iniciar o filtro (${e.javaClass.simpleName}).")
                return@launch
            }

            // Mantém as regras atualizadas enquanto o filtro roda.
            combine(shield.blockedNames, shield.allowedNames) { b, a -> DomainMatcher(b, a) }
                .debounce(300)
                .collect { matcher = it }
        }
    }

    private fun failStart(message: String) {
        started = false
        ShieldRuntime.setError(message)
        ShieldRuntime.setRunning(false)
        stopSelf()
    }

    private fun stopShield(userRequested: Boolean) {
        val wasRunning = tun != null
        started = false
        scope?.cancel()
        scope = null
        pool?.shutdownNow()
        pool = null
        try {
            tun?.close()
        } catch (_: IOException) {
        }
        tun = null
        ShieldRuntime.setRunning(false)
        val c = container
        // Só um pedido explícito do usuário limpa a intenção "ligado"; quedas deixam o estado "interrompida".
        if (userRequested) c.appScope.launch { c.settings.setShieldEnabled(false) }
        if (wasRunning) {
            c.appScope.launch { c.shield.logEvent(if (userRequested) "SHIELD_OFF" else "SHIELD_INTERRUPTED") }
        }
    }

    private fun buildInterface(): ParcelFileDescriptor? {
        val builder = Builder()
            .setSession("VIGIL Shield")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(DNS_ADDRESS)
            .addRoute(DNS_ADDRESS, 32) // somente o DNS virtual passa pela VPN
            .setMtu(1500)
            .setBlocking(true)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        return builder.establish()
    }

    // ---------------------------------------------------------------- leitura de pacotes

    private fun startReader(fd: ParcelFileDescriptor) {
        val thread = Thread({
            val input = FileInputStream(fd.fileDescriptor)
            val output = FileOutputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            try {
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n > 0) handlePacket(buf, n, output)
                }
            } catch (_: IOException) {
                // interface fechada
            }
            // Se o laço terminou sem pedido de parada, o filtro caiu: refletir isso na interface.
            if (started) {
                stopShield(userRequested = false)
                stopSelf()
            }
        }, "vigil-dns")
        thread.isDaemon = true
        thread.start()
    }

    private fun handlePacket(buf: ByteArray, length: Int, out: FileOutputStream) {
        val udp = IpPacket.parseUdp4(buf, length) ?: return
        if (udp.dstPort != 53 || !udp.dstIp.contentEquals(DNS_BYTES)) return

        val question = DnsPacket.parseQuestion(buf, udp.payloadOffset, udp.payloadLength)
        if (question != null) {
            val rule = matcher.matchBlocked(question.name)
            if (rule != null) {
                val response = DnsPacket.buildNxdomain(buf, udp.payloadOffset, question)
                writeReply(udp, response, response.size, out)
                recordBlock(rule)
                return
            }
        }

        val payload = buf.copyOfRange(udp.payloadOffset, udp.payloadOffset + udp.payloadLength)
        pool?.execute {
            try {
                forward(udp, payload, out)
            } catch (_: Exception) {
            }
        }
    }

    private fun writeReply(request: UdpPacket, dns: ByteArray, dnsLength: Int, out: FileOutputStream) {
        val packet = IpPacket.buildUdp4(request.dstIp, request.srcIp, request.dstPort, request.srcPort, dns, dnsLength)
        synchronized(out) { out.write(packet) }
    }

    /** Registra o bloqueio guardando só a regra, no máximo uma vez a cada 30 s por regra. */
    private fun recordBlock(rule: String) {
        val now = SystemClock.elapsedRealtime()
        val last = lastLogged[rule]
        if (last != null && now - last < LOG_THROTTLE_MS) return
        lastLogged[rule] = now
        val c = container
        c.appScope.launch { c.shield.logEvent("BLOCK", rule) }
    }

    // ---------------------------------------------------------------- encaminhamento

    private fun forward(request: UdpPacket, payload: ByteArray, out: FileOutputStream) {
        var attempt = 0
        while (attempt < 2) {
            val target = currentUpstream(force = attempt > 0)
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                protect(socket) // fora da VPN, senão a consulta voltaria para cá em laço
                target.network?.bindSocket(socket)
                socket.soTimeout = UPSTREAM_TIMEOUT_MS
                socket.connect(InetSocketAddress(target.address, 53))
                socket.send(DatagramPacket(payload, payload.size))
                val buf = ByteArray(4096)
                val response = DatagramPacket(buf, buf.size)
                socket.receive(response)
                writeReply(request, buf, response.length, out)
                return
            } catch (_: Exception) {
                attempt++
            } finally {
                socket?.close()
            }
        }
    }

    private fun currentUpstream(force: Boolean): ResolverTarget {
        val now = SystemClock.elapsedRealtime()
        val current = upstream
        if (!force && current != null && now - upstreamAt < UPSTREAM_REFRESH_MS) return current
        val fresh = findUpstream()
        upstream = fresh
        upstreamAt = now
        return fresh
    }

    /**
     * Escolhe o DNS IPv4 de uma rede real (não-VPN) com internet, preferindo redes validadas.
     * Se nada for encontrado, usa 1.1.1.1 como último recurso (único endereço externo fixo do app,
     * usado apenas para encaminhar consultas que não foram bloqueadas).
     */
    private fun findUpstream(): ResolverTarget {
        val cm = getSystemService(ConnectivityManager::class.java)
        var fallback: ResolverTarget? = null
        @Suppress("DEPRECATION")
        for (network in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue
            val dns = cm.getLinkProperties(network)?.dnsServers?.firstOrNull { it is Inet4Address } ?: continue
            val target = ResolverTarget(network, dns)
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) return target
            if (fallback == null) fallback = target
        }
        return fallback ?: ResolverTarget(null, InetAddress.getByAddress(byteArrayOf(1, 1, 1, 1)))
    }
}
