package app.vigil.core.util

/**
 * Lê linhas de listas de domínios importadas pelo usuário.
 *
 * Formatos aceitos:
 * - "exemplo.com"
 * - "0.0.0.0 exemplo.com" ou "127.0.0.1 exemplo.com" (formato hosts)
 * - qualquer um dos acima seguido de "# comentário"
 *
 * Linhas vazias, comentários e entradas inválidas (inclusive "localhost" e endereços IP) são ignorados.
 */
object DomainListParser {
    private val whitespace = Regex("\\s+")
    private val hostsAddresses = setOf("0.0.0.0", "127.0.0.1", "::", "::1")

    /** Retorna o domínio normalizado da linha, ou null se não houver um domínio válido. */
    fun parseLine(line: String): String? {
        val content = line.substringBefore('#').trim()
        if (content.isEmpty()) return null
        val tokens = content.split(whitespace)
        val candidate = when {
            tokens.size == 1 -> tokens[0]
            tokens.size >= 2 && tokens[0] in hostsAddresses -> tokens[1]
            else -> return null
        }
        return DomainNormalizer.normalize(candidate)
    }

    /** Verdadeiro para linhas que não têm conteúdo útil (vazias ou só comentário). */
    fun isBlankOrComment(line: String): Boolean = line.substringBefore('#').isBlank()
}
