package app.vigil.feature.shield.engine

import android.content.Context
import android.content.Intent
import android.net.VpnService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Estado real do filtro, escrito pelo [VigilVpnService] e lido pela interface. */
object ShieldRuntime {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    internal fun setRunning(value: Boolean) {
        _running.value = value
    }

    internal fun setError(value: String?) {
        _error.value = value
    }
}

/** Ponto de entrada da interface para ligar e desligar o filtro. */
object ShieldController {
    /** Retorna um Intent de consentimento se o usuário ainda não autorizou a VPN; null se já autorizou. */
    fun prepareIntent(context: Context): Intent? = VpnService.prepare(context)

    fun start(context: Context) {
        context.startService(
            Intent(context, VigilVpnService::class.java).setAction(VigilVpnService.ACTION_START),
        )
    }

    fun stop(context: Context) {
        context.startService(
            Intent(context, VigilVpnService::class.java).setAction(VigilVpnService.ACTION_STOP),
        )
    }
}
