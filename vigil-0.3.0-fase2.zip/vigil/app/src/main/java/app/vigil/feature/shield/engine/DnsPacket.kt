package app.vigil.feature.shield.engine

/** Datagrama UDP/IPv4 lido da interface TUN. Os endereços são cópias; [payloadOffset] aponta para o buffer original. */
class UdpPacket(
    val srcIp: ByteArray,
    val dstIp: ByteArray,
    val srcPort: Int,
    val dstPort: Int,
    val payloadOffset: Int,
    val payloadLength: Int,
)

/** Primeira pergunta de uma mensagem DNS. [endOffset] é o índice logo após a seção de pergunta. */
class DnsQuestion(val name: String, val type: Int, val endOffset: Int)

object IpPacket {
    fun u16(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    /** Interpreta um pacote IPv4 contendo UDP. Retorna null para qualquer outra coisa (TCP, IPv6, fragmentos, truncados). */
    fun parseUdp4(buf: ByteArray, length: Int): UdpPacket? {
        if (length < 28 || length > buf.size) return null
        val first = buf[0].toInt() and 0xFF
        if ((first shr 4) != 4) return null
        val ihl = (first and 0x0F) * 4
        if (ihl < 20 || length < ihl + 8) return null
        if ((buf[9].toInt() and 0xFF) != 17) return null
        // Flags/offset: bit 0x4000 é DF (ok); 0x2000 é MF e 0x1FFF é o deslocamento (fragmento, não suportado).
        if ((u16(buf, 6) and 0x3FFF) != 0) return null
        val totalLength = u16(buf, 2)
        if (totalLength < ihl + 8 || totalLength > length) return null
        val udpLength = u16(buf, ihl + 4)
        if (udpLength < 8 || ihl + udpLength > totalLength) return null
        return UdpPacket(
            srcIp = buf.copyOfRange(12, 16),
            dstIp = buf.copyOfRange(16, 20),
            srcPort = u16(buf, ihl),
            dstPort = u16(buf, ihl + 2),
            payloadOffset = ihl + 8,
            payloadLength = udpLength - 8,
        )
    }

    /** Monta um pacote IPv4/UDP completo, com checksums de IP e de UDP calculados. */
    fun buildUdp4(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray,
        payloadLength: Int = payload.size,
    ): ByteArray {
        val udpLength = 8 + payloadLength
        val total = 20 + udpLength
        val out = ByteArray(total)
        out[0] = 0x45
        out[2] = (total shr 8).toByte()
        out[3] = total.toByte()
        out[6] = 0x40 // DF
        out[8] = 64 // TTL
        out[9] = 17 // UDP
        System.arraycopy(srcIp, 0, out, 12, 4)
        System.arraycopy(dstIp, 0, out, 16, 4)
        val ipSum = checksum(out, 0, 20)
        out[10] = (ipSum shr 8).toByte()
        out[11] = ipSum.toByte()

        out[20] = (srcPort shr 8).toByte()
        out[21] = srcPort.toByte()
        out[22] = (dstPort shr 8).toByte()
        out[23] = dstPort.toByte()
        out[24] = (udpLength shr 8).toByte()
        out[25] = udpLength.toByte()
        System.arraycopy(payload, 0, out, 28, payloadLength)

        var udpSum = checksum(out, 20, udpLength, pseudoHeaderSum(srcIp, dstIp, udpLength))
        if (udpSum == 0) udpSum = 0xFFFF
        out[26] = (udpSum shr 8).toByte()
        out[27] = udpSum.toByte()
        return out
    }

    /** Soma (sem inverter) do pseudo-cabeçalho IPv4 usado no checksum de UDP. */
    fun pseudoHeaderSum(srcIp: ByteArray, dstIp: ByteArray, udpLength: Int): Long =
        (u16(srcIp, 0) + u16(srcIp, 2) + u16(dstIp, 0) + u16(dstIp, 2) + 17 + udpLength).toLong()

    /** Checksum da Internet (complemento de um da soma de palavras de 16 bits). Sobre dados válidos, o resultado é 0. */
    fun checksum(b: ByteArray, off: Int, len: Int, initial: Long = 0L): Int {
        var sum = initial
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += u16(b, i)
            i += 2
        }
        if (i < end) sum += (b[i].toInt() and 0xFF) shl 8
        while ((sum shr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return sum.inv().toInt() and 0xFFFF
    }
}

object DnsPacket {
    const val HEADER_SIZE = 12

    /**
     * Lê a primeira pergunta de uma consulta DNS (QR=0, opcode QUERY).
     * Retorna null se a mensagem não for uma consulta bem formada; nesse caso o chamador deve apenas encaminhá-la.
     */
    fun parseQuestion(buf: ByteArray, offset: Int, length: Int): DnsQuestion? {
        if (length < HEADER_SIZE + 5 || offset + length > buf.size) return null
        val end = offset + length
        val flags = IpPacket.u16(buf, offset + 2)
        if ((flags and 0x8000) != 0) return null // já é resposta
        if ((flags and 0x7800) != 0) return null // opcode diferente de QUERY
        if (IpPacket.u16(buf, offset + 4) < 1) return null // QDCOUNT

        var pos = offset + HEADER_SIZE
        val name = StringBuilder()
        while (true) {
            if (pos >= end) return null
            val labelLength = buf[pos].toInt() and 0xFF
            if (labelLength == 0) {
                pos++
                break
            }
            if ((labelLength and 0xC0) != 0) return null // compressão não é esperada na pergunta
            if (pos + 1 + labelLength > end) return null
            if (name.isNotEmpty()) name.append('.')
            for (i in 0 until labelLength) {
                name.append((buf[pos + 1 + i].toInt() and 0xFF).toChar())
            }
            pos += 1 + labelLength
            if (name.length > 253) return null
        }
        if (pos + 4 > end) return null
        val type = IpPacket.u16(buf, pos)
        return DnsQuestion(name.toString().lowercase(), type, pos + 4)
    }

    /** Resposta NXDOMAIN (RCODE 3) para a consulta, repetindo o ID e a seção de pergunta. */
    fun buildNxdomain(query: ByteArray, offset: Int, question: DnsQuestion): ByteArray {
        val questionLength = question.endOffset - (offset + HEADER_SIZE)
        val out = ByteArray(HEADER_SIZE + questionLength)
        out[0] = query[offset]
        out[1] = query[offset + 1]
        val requestFlags = IpPacket.u16(query, offset + 2)
        // QR=1, copia opcode e RD, RA=1, RCODE=3
        val flags = 0x8000 or (requestFlags and 0x7800) or (requestFlags and 0x0100) or 0x0080 or 0x0003
        out[2] = (flags shr 8).toByte()
        out[3] = flags.toByte()
        out[5] = 1 // QDCOUNT
        System.arraycopy(query, offset + HEADER_SIZE, out, HEADER_SIZE, questionLength)
        return out
    }
}
