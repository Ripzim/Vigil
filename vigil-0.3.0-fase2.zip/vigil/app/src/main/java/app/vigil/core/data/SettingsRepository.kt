package app.vigil.core.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.vigilDataStore: DataStore<Preferences> by preferencesDataStore(name = "vigil_settings")

/** Configurações do app, armazenadas localmente no DataStore. */
class SettingsRepository(private val store: DataStore<Preferences>) {
    private val advancedKey = booleanPreferencesKey("advanced_dashboard")
    private val shieldEnabledKey = booleanPreferencesKey("shield_enabled")
    private val passwordKey = stringPreferencesKey("password_record")
    private val emergencyKey = longPreferencesKey("emergency_requested_at")

    val advancedDashboard: Flow<Boolean> = store.data.map { it[advancedKey] ?: false }

    /** Intenção do usuário: o Shield foi ligado e não foi desligado por ele. Diferente de estar rodando agora. */
    val shieldEnabled: Flow<Boolean> = store.data.map { it[shieldEnabledKey] ?: false }

    /** Registro do hash da senha (nunca a senha). Null quando não há senha. */
    val passwordRecord: Flow<String?> = store.data.map { it[passwordKey] }

    /** Momento em que o usuário pediu a redefinição de emergência, ou null. */
    val emergencyRequestedAt: Flow<Long?> = store.data.map { it[emergencyKey] }

    suspend fun setAdvancedDashboard(value: Boolean) {
        store.edit { it[advancedKey] = value }
    }

    suspend fun setShieldEnabled(value: Boolean) {
        store.edit { it[shieldEnabledKey] = value }
    }

    suspend fun setPasswordRecord(record: String?) {
        store.edit {
            if (record == null) it.remove(passwordKey) else it[passwordKey] = record
        }
    }

    suspend fun setEmergencyRequestedAt(timestamp: Long?) {
        store.edit {
            if (timestamp == null) it.remove(emergencyKey) else it[emergencyKey] = timestamp
        }
    }

    suspend fun clear() {
        store.edit { it.clear() }
    }
}
