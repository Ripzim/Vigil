package app.vigil.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey

/**
 * "Pimenta" da senha: HMAC-SHA256 com uma chave gerada e guardada no Android Keystore.
 * A chave não é exportável, então o hash gravado no DataStore não pode ser testado fora deste aparelho.
 */
object KeystorePepper {
    private const val ALIAS = "vigil_password_pepper"
    private const val PROVIDER = "AndroidKeyStore"

    fun apply(data: ByteArray): ByteArray {
        val store = KeyStore.getInstance(PROVIDER).apply { load(null) }
        var key = store.getKey(ALIAS, null) as? SecretKey
        if (key == null) {
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, PROVIDER)
            generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN).build())
            key = generator.generateKey()
        }
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(key)
        return mac.doFinal(data)
    }
}
