package app.vigil.core.security

import app.vigil.core.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

sealed interface AuthResult {
    data object Ok : AuthResult
    data object Wrong : AuthResult
    data class Locked(val seconds: Int) : AuthResult
}

/**
 * Senha de proteção contra alterações impulsivas.
 *
 * Isto NÃO é um mecanismo para trancar o usuário fora: o Android sempre permite desligar uma VPN em
 * Configurações > Conexões > Mais configurações de conexão > VPN, e desinstalar o app. A senha só
 * coloca atrito entre o impulso e a desativação.
 *
 * Recuperação de emergência (esquecimento da senha): o usuário pede a redefinição e, após
 * [EMERGENCY_WAIT_MS] (24 h), pode definir uma nova senha sem informar a antiga. A espera existe para
 * que um impulso passe, e nunca impede o acesso definitivamente. (A redefinição por reprodução de textos
 * prevista no projeto chega na Fase 3.)
 */
class PasswordManager(private val settings: SettingsRepository) {
    private val hasher = PasswordHasher(pepper = { KeystorePepper.apply(it) })

    val hasPassword: Flow<Boolean> = settings.passwordRecord.map { it != null }
    val emergencyRequestedAt: Flow<Long?> = settings.emergencyRequestedAt

    private var failures = 0
    private var lockedUntil = 0L

    suspend fun hasPasswordNow(): Boolean = settings.passwordRecord.first() != null

    /** Confere a senha. Sem senha definida, retorna [AuthResult.Ok]. */
    suspend fun verify(password: String): AuthResult {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) return AuthResult.Locked(secondsLeft(lockedUntil - now))
        val record = settings.passwordRecord.first() ?: return AuthResult.Ok
        val ok = withContext(Dispatchers.Default) { hasher.verify(password.toCharArray(), record) }
        if (ok) {
            failures = 0
            // Quem lembrou da senha cancela qualquer pedido de emergência pendente.
            if (settings.emergencyRequestedAt.first() != null) settings.setEmergencyRequestedAt(null)
            return AuthResult.Ok
        }
        failures++
        if (failures >= MAX_FAILURES) {
            failures = 0
            lockedUntil = System.currentTimeMillis() + LOCK_MS
            return AuthResult.Locked(secondsLeft(LOCK_MS))
        }
        return AuthResult.Wrong
    }

    /** Define (ou troca) a senha. Quem chama é responsável por ter autenticado antes. */
    suspend fun setPassword(newPassword: String): Boolean {
        if (newPassword.length < MIN_LENGTH) return false
        val record = withContext(Dispatchers.Default) { hasher.hash(newPassword.toCharArray()) }
        settings.setPasswordRecord(record)
        settings.setEmergencyRequestedAt(null)
        return true
    }

    suspend fun removePassword() {
        settings.setPasswordRecord(null)
        settings.setEmergencyRequestedAt(null)
    }

    suspend fun requestEmergencyReset() {
        if (settings.emergencyRequestedAt.first() == null) {
            settings.setEmergencyRequestedAt(System.currentTimeMillis())
        }
    }

    suspend fun cancelEmergencyReset() = settings.setEmergencyRequestedAt(null)

    /** Só funciona depois da espera de 24 h desde o pedido. */
    suspend fun resetViaEmergency(newPassword: String): Boolean {
        val requestedAt = settings.emergencyRequestedAt.first() ?: return false
        if (System.currentTimeMillis() - requestedAt < EMERGENCY_WAIT_MS) return false
        return setPassword(newPassword)
    }

    private fun secondsLeft(ms: Long): Int = ((ms + 999) / 1000).toInt()

    companion object {
        const val MIN_LENGTH = 6
        const val EMERGENCY_WAIT_MS = 24L * 60 * 60 * 1000
        private const val MAX_FAILURES = 5
        private const val LOCK_MS = 30_000L
    }
}
