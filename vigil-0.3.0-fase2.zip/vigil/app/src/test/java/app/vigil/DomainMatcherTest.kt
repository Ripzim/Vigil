package app.vigil

import app.vigil.feature.shield.engine.DomainMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DomainMatcherTest {
    private val matcher = DomainMatcher(blocked = listOf("exemplo.com"), allowed = emptyList())

    @Test fun blocksExactDomain() = assertEquals("exemplo.com", matcher.matchBlocked("exemplo.com"))

    @Test fun blocksSubdomains() {
        assertEquals("exemplo.com", matcher.matchBlocked("www.exemplo.com"))
        assertEquals("exemplo.com", matcher.matchBlocked("a.b.exemplo.com"))
    }

    @Test fun doesNotMatchPartialLabelOrOtherTld() {
        assertNull(matcher.matchBlocked("naoexemplo.com"))
        assertNull(matcher.matchBlocked("exemplo.com.br"))
        assertNull(matcher.matchBlocked("com"))
    }

    @Test fun ignoresCaseAndTrailingDot() = assertEquals("exemplo.com", matcher.matchBlocked("EXEMPLO.COM."))

    @Test fun emptyNameAndEmptyListNeverBlock() {
        assertNull(matcher.matchBlocked(""))
        assertNull(DomainMatcher(emptyList(), emptyList()).matchBlocked("exemplo.com"))
    }

    @Test fun allowListTakesPrecedence() {
        val m = DomainMatcher(blocked = listOf("exemplo.com"), allowed = listOf("ok.exemplo.com"))
        assertNull(m.matchBlocked("ok.exemplo.com"))
        assertNull(m.matchBlocked("x.ok.exemplo.com"))
        assertEquals("exemplo.com", m.matchBlocked("exemplo.com"))
        assertEquals("exemplo.com", m.matchBlocked("outro.exemplo.com"))
    }

    @Test fun returnsMostSpecificRule() {
        val m = DomainMatcher(blocked = listOf("a.com", "b.a.com"), allowed = emptyList())
        assertEquals("b.a.com", m.matchBlocked("c.b.a.com"))
        assertEquals("a.com", m.matchBlocked("z.a.com"))
    }
}
