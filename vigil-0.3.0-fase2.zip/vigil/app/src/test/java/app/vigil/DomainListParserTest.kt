package app.vigil

import app.vigil.core.util.DomainListParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainListParserTest {
    @Test fun plainDomain() = assertEquals("exemplo.com", DomainListParser.parseLine("exemplo.com"))

    @Test fun hostsFormat() {
        assertEquals("exemplo.com", DomainListParser.parseLine("0.0.0.0 Exemplo.com"))
        assertEquals("exemplo.com", DomainListParser.parseLine("127.0.0.1\texemplo.com # comentário"))
    }

    @Test fun commentsAndBlankLinesAreIgnored() {
        assertNull(DomainListParser.parseLine("# só comentário"))
        assertNull(DomainListParser.parseLine("   "))
        assertNull(DomainListParser.parseLine(""))
        assertTrue(DomainListParser.isBlankOrComment("# só comentário"))
        assertTrue(DomainListParser.isBlankOrComment(""))
        assertFalse(DomainListParser.isBlankOrComment("exemplo.com"))
    }

    @Test fun junkIsRejected() {
        assertNull(DomainListParser.parseLine("0.0.0.0 localhost"))
        assertNull(DomainListParser.parseLine("0.0.0.0 0.0.0.0"))
        assertNull(DomainListParser.parseLine("um dois três"))
        assertNull(DomainListParser.parseLine("||exemplo.com^"))
        assertFalse(DomainListParser.isBlankOrComment("um dois três"))
    }
}
