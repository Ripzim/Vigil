package app.vigil

import app.vigil.core.security.PasswordHasher
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHasherTest {
    // Poucas iterações só para os testes ficarem rápidos; o app usa DEFAULT_ITERATIONS.
    private val plain = PasswordHasher(pepper = null, iterations = 1000)
    private val xorPepper: (ByteArray) -> ByteArray = { b -> ByteArray(b.size) { (b[it].toInt() xor 0x5A).toByte() } }

    @Test fun correctPasswordVerifiesAndWrongOneDoesNot() {
        val record = plain.hash("senha-forte".toCharArray())
        assertTrue(record.startsWith("v1:1000:"))
        assertTrue(plain.verify("senha-forte".toCharArray(), record))
        assertFalse(plain.verify("senha-fortE".toCharArray(), record))
        assertFalse(plain.verify("".toCharArray(), record))
    }

    @Test fun recordNeverContainsThePassword() {
        val record = plain.hash("segredo123".toCharArray())
        assertFalse(record.contains("segredo123"))
    }

    @Test fun sameSaltIsNeverReused() {
        val a = plain.hash("abcdef".toCharArray())
        val b = plain.hash("abcdef".toCharArray())
        assertNotEquals(a, b)
    }

    @Test fun pepperedRecordsRequireThePepper() {
        val peppered = PasswordHasher(pepper = xorPepper, iterations = 1000)
        val record = peppered.hash("abcdef".toCharArray())
        assertTrue(record.startsWith("v2:"))
        assertTrue(peppered.verify("abcdef".toCharArray(), record))
        assertFalse(plain.verify("abcdef".toCharArray(), record))
    }

    @Test fun fallsBackToV1WhenPepperFails() {
        val broken = PasswordHasher(pepper = { _ -> throw IllegalStateException("keystore") }, iterations = 1000)
        val record = broken.hash("abcdef".toCharArray())
        assertTrue(record.startsWith("v1:"))
        assertTrue(plain.verify("abcdef".toCharArray(), record))
    }

    @Test fun malformedRecordsAreRejected() {
        listOf("", "abc", "v3:1000:aa:bb", "v1:x:aa:bb", "v1:0:aa:bb", "v1:1000:!!!:!!!").forEach {
            assertFalse(it, plain.verify("abcdef".toCharArray(), it))
        }
    }
}
