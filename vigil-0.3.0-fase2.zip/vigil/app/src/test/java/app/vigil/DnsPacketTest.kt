package app.vigil

import app.vigil.feature.shield.engine.DnsPacket
import app.vigil.feature.shield.engine.IpPacket
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsPacketTest {
    private val clientIp = byteArrayOf(10, 111, 222.toByte(), 1)
    private val dnsIp = byteArrayOf(10, 111, 222.toByte(), 2)

    private fun query(name: String, id: Int = 0x1234, type: Int = 1, flags: Int = 0x0100): ByteArray {
        val out = ByteArrayOutputStream()
        fun w16(v: Int) {
            out.write(v shr 8)
            out.write(v and 0xFF)
        }
        w16(id); w16(flags); w16(1); w16(0); w16(0); w16(0)
        name.split('.').forEach { label ->
            out.write(label.length)
            out.write(label.toByteArray(Charsets.US_ASCII))
        }
        out.write(0)
        w16(type); w16(1)
        return out.toByteArray()
    }

    // ---- DNS

    @Test fun parsesQuestionAndLowercasesName() {
        val q = query("WWW.Exemplo.com", type = 28)
        val parsed = DnsPacket.parseQuestion(q, 0, q.size)
        assertNotNull(parsed)
        assertEquals("www.exemplo.com", parsed!!.name)
        assertEquals(28, parsed.type)
        assertEquals(q.size, parsed.endOffset)
    }

    @Test fun parsesQuestionAtNonZeroOffset() {
        val q = query("exemplo.com")
        val buf = ByteArray(28) + q
        val parsed = DnsPacket.parseQuestion(buf, 28, q.size)
        assertEquals("exemplo.com", parsed!!.name)
        assertEquals(buf.size, parsed.endOffset)
    }

    @Test fun rejectsResponsesTruncatedAndCompressed() {
        val response = query("exemplo.com", flags = 0x8180)
        assertNull(DnsPacket.parseQuestion(response, 0, response.size))

        val q = query("exemplo.com")
        assertNull(DnsPacket.parseQuestion(q, 0, q.size - 6))
        assertNull(DnsPacket.parseQuestion(q, 0, 5))

        val compressed = ByteArray(17)
        compressed[5] = 1 // QDCOUNT
        compressed[12] = 0xC0.toByte()
        compressed[13] = 0x0C
        assertNull(DnsPacket.parseQuestion(compressed, 0, compressed.size))
    }

    @Test fun nxdomainResponseKeepsIdQuestionAndSetsFlags() {
        val q = query("exemplo.com", id = 0xBEEF)
        val question = DnsPacket.parseQuestion(q, 0, q.size)!!
        val r = DnsPacket.buildNxdomain(q, 0, question)

        assertEquals(0xBEEF, IpPacket.u16(r, 0))
        val flags = IpPacket.u16(r, 2)
        assertTrue("QR", (flags and 0x8000) != 0)
        assertTrue("RD copiado", (flags and 0x0100) != 0)
        assertTrue("RA", (flags and 0x0080) != 0)
        assertEquals("RCODE=NXDOMAIN", 3, flags and 0x000F)
        assertEquals(1, IpPacket.u16(r, 4)) // QDCOUNT
        assertEquals(0, IpPacket.u16(r, 6)) // ANCOUNT
        assertEquals(0, IpPacket.u16(r, 8))
        assertEquals(0, IpPacket.u16(r, 10))
        assertArrayEquals(q.copyOfRange(12, q.size), r.copyOfRange(12, r.size))
    }

    // ---- IPv4/UDP

    @Test fun headerChecksumMatchesKnownVector() {
        // Exemplo clássico de cabeçalho IPv4 (checksum esperado 0xB861).
        val header = byteArrayOf(
            0x45, 0x00, 0x00, 0x73, 0x00, 0x00, 0x40, 0x00, 0x40, 0x11, 0x00, 0x00,
            0xC0.toByte(), 0xA8.toByte(), 0x00, 0x01, 0xC0.toByte(), 0xA8.toByte(), 0x00, 0xC7.toByte(),
        )
        assertEquals(0xB861, IpPacket.checksum(header, 0, 20))
    }

    @Test fun buildThenParseRoundTrip() {
        val payload = query("exemplo.com")
        val pkt = IpPacket.buildUdp4(dnsIp, clientIp, 53, 40000, payload)
        val parsed = IpPacket.parseUdp4(pkt, pkt.size)
        assertNotNull(parsed)
        parsed!!
        assertArrayEquals(dnsIp, parsed.srcIp)
        assertArrayEquals(clientIp, parsed.dstIp)
        assertEquals(53, parsed.srcPort)
        assertEquals(40000, parsed.dstPort)
        assertArrayEquals(payload, pkt.copyOfRange(parsed.payloadOffset, parsed.payloadOffset + parsed.payloadLength))
    }

    @Test fun builtPacketsHaveValidChecksums() {
        for (size in listOf(0, 1, 5, 12, 33)) { // inclui tamanhos ímpares
            val payload = ByteArray(size) { (it * 7 + 3).toByte() }
            val pkt = IpPacket.buildUdp4(dnsIp, clientIp, 53, 40000, payload)
            assertEquals("IP size=$size", 0, IpPacket.checksum(pkt, 0, 20))
            val udpLength = 8 + size
            val sum = IpPacket.checksum(pkt, 20, udpLength, IpPacket.pseudoHeaderSum(dnsIp, clientIp, udpLength))
            assertEquals("UDP size=$size", 0, sum)
        }
    }

    @Test fun parseRejectsNonUdpFragmentsShortAndIpv6() {
        val good = IpPacket.buildUdp4(clientIp, dnsIp, 40000, 53, query("exemplo.com"))

        val tcp = good.copyOf().also { it[9] = 6 }
        assertNull(IpPacket.parseUdp4(tcp, tcp.size))

        val fragment = good.copyOf().also { it[6] = 0x20 } // MF
        assertNull(IpPacket.parseUdp4(fragment, fragment.size))

        assertNull(IpPacket.parseUdp4(good, 20))

        val v6 = good.copyOf().also { it[0] = 0x60 }
        assertNull(IpPacket.parseUdp4(v6, v6.size))

        // Tamanho total maior do que os bytes lidos.
        assertNull(IpPacket.parseUdp4(good, good.size - 4))
    }
}
