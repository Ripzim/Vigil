# VIGIL 0.3.0 — Fases 1 e 2

> Vigie. Resista. Persevere.

App Android nativo (Kotlin, Jetpack Compose, Material 3) de disciplina digital e recuperação, com identidade cristã reformada. Local-first: sem contas, telemetria, anúncios ou servidores próprios.

## Estado desta entrega

**Importante:** todo o código foi escrito sem acesso a Android SDK nem a repositórios Maven/Gradle (o ambiente de desenvolvimento bloqueava essas redes). **Nada foi compilado nem executado.** O que foi verificado fora do Android: o cálculo de checksums e o layout dos pacotes IPv4/UDP, reimplementados em Python e conferidos contra um vetor conhecido. A primeira compilação real e os testes unitários rodam no GitHub Actions. Se o build falhar, o log do erro é o próximo passo.

| Módulo | Estado |
|---|---|
| Fase 1: tema AMOLED, navegação, dashboard, Room, DataStore, Watch manual, Recovery, Devotion | Escrito, não compilado |
| **Shield: filtro DNS via VpnService** | Escrito, **não compilado e não testado em aparelho** |
| Shield: listas de bloqueio/permissão, importação de arquivo, lista inicial mínima | Escrito, não compilado |
| Shield: teste de bloqueio dentro do app (resolve um domínio bloqueado e um de controle) | Escrito, não compilado |
| Proteção por senha (PBKDF2 + chave do Android Keystore, limite de tentativas) | Escrito, não compilado |
| Recuperação de emergência da senha (espera de 24 h) | Escrito, não compilado |
| Textos de recuperação com similaridade ≥ 80%, duração da desativação, reativação automática | **Não iniciado (Fase 3)** |
| Alertas e notificações do Watch | Não iniciado (Fase 3) |
| Intelligence, Vision | Apenas tela de status |

Testes unitários escritos (não executados): `DomainNormalizerTest`, `DevotionContentTest`, `DomainMatcherTest`, `DnsPacketTest`, `PasswordHasherTest`, `DomainListParserTest`.

**Não considere o filtro "pronto" até o teste de bloqueio do app mostrar `OK` no seu Galaxy A23.**

## Como o filtro DNS funciona

- Cria uma VPN que roteia **somente** um DNS virtual (`10.111.222.2`) para o app. O resto do tráfego segue direto pela rede, sem passar pelo VIGIL.
- Consulta DNS de domínio na lista de bloqueio recebe resposta NXDOMAIN local. As demais são encaminhadas ao DNS da rede atual por um socket fora da VPN.
- Se o app não achar o DNS da rede, usa `1.1.1.1` como último recurso. Esse é o único endereço externo fixo do app, e só recebe consultas que não foram bloqueadas.
- Sem interceptação de HTTPS, sem certificados, sem leitura de conteúdo. O histórico guarda só a **regra** que bloqueou, nunca o endereço visitado.
- A permissão `INTERNET` existe apenas para esse encaminhamento. Não há servidor do VIGIL, telemetria nem sincronização.

### Limitações conhecidas

- Só trata DNS sobre **UDP e IPv4**. DNS sobre TCP e IPv6 não são tratados.
- **Não protege** apps com DNS próprio (DoH/DoT embutido), nem acesso direto por endereço IP.
- O "DNS privado" do Android e o "DNS seguro" do Chrome em modo estrito **contornam o filtro**. Mantenha o DNS privado em *Automático* ou *Desativado* (Configurações > Conexões > Mais configurações de conexão > DNS privado) e desative "Usar DNS seguro" no Chrome.
- Se o Android reiniciar, outra VPN assumir ou a permissão for revogada, o filtro cai. O app mostra "PROTEÇÃO INTERROMPIDA" e você precisa ativar de novo. Ainda não há reativação automática.
- A senha é um freio contra impulsos, não um cadeado: o Android sempre permite desligar a VPN em Configurações > Conexões > Mais configurações de conexão > VPN, e desinstalar o app.

## Como testar o filtro no aparelho

1. Instale o APK (instruções abaixo) e abra o VIGIL > **Shield**.
2. Em **Bloqueados**, toque em **Lista inicial mínima** (8 domínios, só para teste) ou adicione um domínio que exista de verdade.
3. Ative o **Filtro DNS** e aceite o pedido de VPN do Android. O ícone de chave deve aparecer na barra de status.
4. Toque em **Testar bloqueio**. O resultado esperado é `OK: <domínio> foi bloqueado e example.com resolveu normalmente.`
   - `FALHA`: o domínio resolveu, então não foi bloqueado. Verifique o DNS privado e o DNS seguro do Chrome.
   - `Inconclusivo`: nem o domínio de controle resolveu. Verifique a conexão.
5. Teste também no navegador: abra um site da lista. Ele não deve carregar.

### Listas maiores

A lista inicial é mínima. Para proteção de verdade, baixe uma lista pública mantida pela comunidade, em formato *hosts* ou um domínio por linha, e use **Importar arquivo** no Shield. O projeto `StevenBlack/hosts` no GitHub tem variantes só de conteúdo adulto (procure na pasta `alternates`). Não consegui verificar o caminho exato a partir do ambiente de desenvolvimento.

## Senha e recuperação

- **Configurações > Proteção por senha** define a senha (mínimo de 6 caracteres). Ela é guardada só como hash PBKDF2-HMAC-SHA256 com sal, somado a uma chave do Android Keystore. A senha em texto puro nunca é gravada.
- Com senha definida, ela é pedida para: desativar o Shield, remover domínio bloqueado, mexer na lista de permissões, remover a senha e apagar os dados.
- Depois de 5 erros seguidos, há uma espera de 30 s.
- **Esqueci a senha:** inicia uma espera de 24 horas. Depois dela, é possível definir uma nova senha sem a antiga. Lembrar a senha e usá-la cancela o pedido.
- Procedimento de emergência fora do app: desligar a VPN nas configurações do Android, ou desinstalar o app.

## Arquitetura

- Módulo Gradle único `:app`, com modularidade por pacote (`feature/*`, `core/*`).
- MVVM: Compose → ViewModel → Repository → Room/DataStore. DI manual (`AppContainer`).
- Motor do filtro em `feature/shield/engine` (`VigilVpnService`, `DnsPacket`, `DomainMatcher`), com a lógica de pacotes em Kotlin puro para ser testada na JVM.
- Configurações no DataStore (não há tabela Room de configurações).
- Backup do Android desativado para os dados do VIGIL.
- Limite conhecido: o banco de dados ainda não é criptografado em repouso.

## Como gerar e instalar o APK (sem Android Studio)

1. Crie um repositório no GitHub e envie esta pasta (branch `main`). O arquivo `settings.gradle.kts` deve ficar na raiz do repositório.
2. Abra a aba **Actions**. O workflow **Build APK (debug)** roda sozinho a cada push (ou use **Run workflow**). Ele executa os testes unitários e compila.
3. Quando terminar com ✅, baixe o artefato **vigil-debug-apk** no fim da página da execução (um `.zip`).
4. Extraia o `.zip`, copie o `.apk` para o Galaxy A23 5G e abra o arquivo.
5. Permita "Instalar apps desconhecidos" para o app usado (Arquivos, Chrome etc.). Se o Play Protect avisar, escolha "Instalar mesmo assim".
6. O app aparece como **VIGIL** (id de debug: `app.vigil.debug`).

Se o workflow falhar (❌), abra o passo marcado com X e envie as últimas linhas do erro.

## Próximas fases

3. Recovery (Watch com notificações silenciosas, textos de recuperação e similaridade, duração da desativação e reativação) · 4. Intelligence/Vision · 5. Integração e testes de segurança, bateria e compatibilidade.
